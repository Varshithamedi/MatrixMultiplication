import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Matrix Multiplication App");

        System.out.print("Enter rows for Matrix A: ");
        int rowsA = scanner.nextInt();
        System.out.print("Enter columns for Matrix A / rows for Matrix B: ");
        int colsA = scanner.nextInt();
        System.out.print("Enter columns for Matrix B: ");
        int colsB = scanner.nextInt();

        int[][] matrixA = new int[rowsA][colsA];
        int[][] matrixB = new int[colsA][colsB];

        System.out.println("Enter values for Matrix A:");
        for (int i = 0; i < rowsA; i++) {
            for (int j = 0; j < colsA; j++) {
                matrixA[i][j] = scanner.nextInt();
            }
        }

        System.out.println("Enter values for Matrix B:");
        for (int i = 0; i < colsA; i++) {
            for (int j = 0; j < colsB; j++) {
                matrixB[i][j] = scanner.nextInt();
            }
        }

        int[][] result = MatrixOperations.multiply(matrixA, matrixB);

        System.out.println("Resultant Matrix:");
        for (int[] row : result) {
            for (int val : row) {
                System.out.print(val + " ");
            }
            System.out.println();
        }

        scanner.close();
    }
}
