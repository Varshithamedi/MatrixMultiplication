
Matrix Multiplication App (Java)
================================

How to Compile and Run (CLI):
-----------------------------
1. Open terminal and go to src directory:
   cd src

2. Compile the Java files:
   javac Main.java MatrixOperations.java

3. Run the program:
   java Main

Features:
---------
- Simple console-based matrix multiplication app.
- Input validation for matrix size compatibility.
- Resultant matrix displayed on screen.

Technologies Used:
------------------
- Java (CLI)
- Modular class structure

Author: ChatGPT
